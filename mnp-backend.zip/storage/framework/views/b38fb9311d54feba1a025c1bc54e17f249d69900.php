<?php
echo "<pre>";
print_r($order);
echo "</pre>";
foreach($order->products as $pro){
    echo "<pre>";
    print_r($pro->order_item_id);
    echo "</pre>";
}
?><?php /**PATH C:\wamp64\www\Projects_laravel\mnp-backend\resources\views/emailtemplate2.blade.php ENDPATH**/ ?>