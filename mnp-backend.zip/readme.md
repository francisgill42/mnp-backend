Follow the commands before running the application.

1 php artisan key:generate

2 composer update

3 copy .env.example .env and env configuration with database

4 php artisan migrate

5 php artisan passport:install --force

6 php artisan db:seed

finaly run (php artisan serve)

copy address http://localhost:8000/api/login (only used in postman or api tester)

user name : master@erp.com
password : secret



